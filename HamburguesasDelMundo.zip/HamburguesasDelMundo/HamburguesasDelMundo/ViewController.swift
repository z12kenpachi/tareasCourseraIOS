//
//  ViewController.swift
//  HamburguesasDelMundo
//
//  Created by Daniel Rodriguez on 1/23/17.
//  Copyright © 2017 Pachis Universe. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblPais: UILabel!
    @IBOutlet weak var lblHamburguesa: UILabel!
    let paises = ColeccionDePaises()
    let hamburguesas = ColeccionDeHamburguesa()
    let colores = ColeccionDeColores()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //updateUIWithValues()
    }
    
    @IBAction func nuevaCombinacion(_ sender: Any) {
        print("executing btn")
        updateUIWithValues()
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func updateUIWithValues(){
        self.lblPais.text = paises.obtenPais()
        self.lblHamburguesa.text = hamburguesas.obtenHamburguesa()
        //let color = colores.obtenColor()
        //self.view.backgroundColor = color
        //self.view.tintColor = color
    }


}

