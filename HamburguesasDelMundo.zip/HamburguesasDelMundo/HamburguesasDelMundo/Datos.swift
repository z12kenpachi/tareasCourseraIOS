//
//  Datos.swift
//  HamburguesasDelMundo
//
//  Created by Daniel Rodriguez on 1/23/17.
//  Copyright © 2017 Pachis Universe. All rights reserved.
//

import Foundation
import UIKit

public class ColeccionDePaises {

    let paises = ["Australia", "Bolivia", "Costa Rica", "Dinamarca", "Egipto", "Fiyi" , "Grecia", "Hungría", "Irlanda", "Japón", "Kosovo", "Liberia", "Madagascar", "Nauru", "Omán", "Panamá", "Reino Unido", "Samoa", "Tailandia", "Uruguay"]
    
    func obtenPais() -> String {
        let posicion = Int(arc4random()) % paises.count
        return paises[posicion]
    }
    
}


public class ColeccionDeHamburguesa {
    
    let hamburguesas = ["Burger Joint", "La Xarcutería", "Butcher & Sons", "Cafe Clock", "Umami Burger", "Kiosco", "Flippin' Burgers", "New York Burger" , "Barracuda Diner", "La Burguesía", "Burger 54", "Red Burger Society", "Slater's 50/50", "Ferburger", "Avila Burger", "Diablo Burger", "La Vaca Picada", "Meat Liquor", "Minetta Tavern", "Heart Attack Grill"]
    
    func obtenHamburguesa() -> String {
        let posicion = Int(arc4random()) % hamburguesas.count
        return hamburguesas[posicion]
    }
    
}

public class ColeccionDeColores {
    
    let colores = [UIColor.blue, UIColor.brown, UIColor.cyan, UIColor.gray, UIColor.green, UIColor.orange, UIColor.yellow, UIColor.red, UIColor.purple]
    
    func obtenColor() -> UIColor {
        let posicion = Int(arc4random()) % colores.count
        return colores[posicion]
    }
    
}

