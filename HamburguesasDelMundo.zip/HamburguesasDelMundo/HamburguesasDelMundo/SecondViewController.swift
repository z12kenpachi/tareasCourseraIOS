//
//  SecondViewController.swift
//  HamburguesasDelMundo
//
//  Created by Daniel Rodriguez on 1/23/17.
//  Copyright © 2017 Pachis Universe. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var lblPais: UILabel!
    let paises = ColeccionDePaises()
    @IBOutlet weak var lblHamburguesa: UILabel!
    let hamburguesa = ColeccionDeHamburguesa()
    let colores = ColeccionDeColores()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.lblPais.text = paises.obtenPais()
        self.lblHamburguesa.text = hamburguesa.obtenHamburguesa()
        let color = colores.obtenColor()
        view.backgroundColor = color
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func changeLbl(_ sender: UIButton) {
        self.lblPais.text = paises.obtenPais()
        self.lblHamburguesa.text = hamburguesa.obtenHamburguesa()
        let color = colores.obtenColor()
        view.backgroundColor = color
        
    }
    

}
