//: Reto Velocímetro digital - Daniel Rodríguez


import UIKit

enum Velocidades : Int {

    case Apagado = 0, VelocidadBaja = 20, VelocidadMedia = 50, VelocidadAlta = 120
    
    init( velocidadInicial : Velocidades ){
    self = velocidadInicial
    }
    
}

class Auto {

    var velocidad: Velocidades
    
    init(){
        self.velocidad = Velocidades.init(velocidadInicial: .Apagado)
    }
    
    func cambioDeVelocidad() -> (actual : Int, velocidadEnCadena: String) {
        var mensaje: String
        var velocidadActual: Int
        switch velocidad {
        case .Apagado:
            self.velocidad = .VelocidadBaja
            mensaje = "Apagado"
            velocidadActual = 0
        case .VelocidadBaja :
            self.velocidad = .VelocidadMedia
            mensaje = "Velocidad Baja"
            velocidadActual = 20
        case .VelocidadMedia:
            self.velocidad = .VelocidadAlta
            mensaje = "Velocidad Media"
            velocidadActual = 50
        case .VelocidadAlta:
            self.velocidad = .VelocidadMedia
            mensaje = "Velocidad Alta"
            velocidadActual = 120
        }
    
    return (velocidadActual, mensaje)
    }
    
}


let auto: Auto = Auto.init()

for index in 1...20{
    print(auto.cambioDeVelocidad())
}







