//
//  ViewController.swift
//  ReproductorDeMusica
//
//  Created by Daniel Rodriguez on 1/19/17.
//  Copyright © 2017 Pachis Universe. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    
    @IBOutlet weak var sliderVolume: UISlider!
    @IBOutlet weak var lblVolume: UILabel!
    @IBOutlet weak var imageViewCover: UIImageView!
    @IBOutlet weak var btnRandomSong: UIButton!
    @IBOutlet weak var tableViewCanciones: UITableView!
    @IBOutlet weak var lblCurrentSong: UILabel!
    @IBOutlet weak var btnPlay: UIButton!
    @IBOutlet weak var btnPause: UIButton!
    @IBOutlet weak var btnStop: UIButton!
    let songs = ["Alunizar", "Como Saber", "Lithium", "Even Flow", "Poison"]
    var reproductor: AVAudioPlayer!
    var currentSongNumber: Int = -1
    var currentVolume: Float = 0.5
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        tableViewCanciones.tableFooterView = UIView()
        self.lblCurrentSong.text = "Sonando:"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func playSong(_ sender: Any) {
        if !reproductor.isPlaying{
            reproductor.play()
        }
    }

    @IBAction func pauseSong(_ sender: Any) {
        if reproductor.isPlaying{
            reproductor.pause()
        }
    }
    
    @IBAction func stopSong(_ sender: Any) {
            reproductor.stop()
            reproductor.currentTime = 0.0
    }
    
    
    @IBAction func randomSong(_ sender: Any) {
        let random = Int(arc4random_uniform(5))
        let sonidoURL = Bundle.main.url(forResource: songs[random], withExtension: "mp3")
        do{
            try reproductor = AVAudioPlayer(contentsOf: sonidoURL!)
            self.lblCurrentSong.text = "Sonando: \(songs[random])"
            changeAlbumCover(songPosition: random)
            reproductor.volume = currentVolume
            reproductor.play()
        }catch{
            print("Error al leer la cancion")
        }
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return songs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableViewCanciones.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CustomCell
        cell.lblSongInList.text = songs[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(songs[indexPath.row])
        let sonidoURL = Bundle.main.url(forResource: songs[indexPath.row], withExtension: "mp3")
        do{
            try reproductor = AVAudioPlayer(contentsOf: sonidoURL!)
            self.lblCurrentSong.text = "Sonando: \(songs[indexPath.row])"
            currentSongNumber = indexPath.row
            changeAlbumCover(songPosition: indexPath.row)
            reproductor.volume = currentVolume
            reproductor.play()
        }catch{
        print("Error al leer la cancion")
        }
    }
    
    func changeAlbumCover(songPosition: Int){
        switch songPosition {
        case 0:
            self.imageViewCover.image = UIImage(named:"akasha")
        case 1:
            self.imageViewCover.image = UIImage(named:"percance")
        case 2:
            self.imageViewCover.image = UIImage(named:"nirvana")
        case 3:
            self.imageViewCover.image = UIImage(named:"pearl jam")
        case 4:
            self.imageViewCover.image = UIImage(named:"alice cooper")
        default:
            self.imageViewCover.image = UIImage(named:"brokenIcon")
        }
    }
    
    
    @IBAction func sliderValueChanged(_ sender: UISlider) {
        let currentValue = Float(sender.value)
        
        currentVolume = Float(currentValue/100)
        lblVolume.text = String(Int(currentValue))
        if(reproductor != nil){
            reproductor.volume = currentVolume
        }
        
    }
    
    

}

