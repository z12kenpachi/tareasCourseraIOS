//
//  CustomCell.swift
//  ReproductorDeMusica
//
//  Created by Daniel Rodriguez on 1/20/17.
//  Copyright © 2017 Pachis Universe. All rights reserved.
//

import UIKit

class CustomCell: UITableViewCell {

    @IBOutlet weak var lblSongInList: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
