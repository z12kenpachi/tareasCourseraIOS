//
//  ViewController.swift
//  MarcandoLaRuta
//
//  Created by Daniel Rodriguez on 2/3/17.
//  Copyright © 2017 Pachis Universe. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController,CLLocationManagerDelegate {

    @IBOutlet weak var mapa: MKMapView!
    
    private let manejador = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        manejador.delegate = self
        manejador.desiredAccuracy = kCLLocationAccuracyBest
        manejador.requestWhenInUseAuthorization()
        mapa.userTrackingMode = .follow
        
    }
    
    var startLocation:CLLocation!
    var lastLocation: CLLocation!
    var traveledDistance:Double = 0
    var fiftyMeterCounter = 0.0
    var latestLocation: CLLocation!
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        if startLocation == nil {
            startLocation = locations.first
        } else {
            if let lastLocation = locations.last {
                let distance = startLocation.distance(from: lastLocation)
                let lastDistance = lastLocation.distance(from: lastLocation)
                traveledDistance += lastDistance
                print("START LOCATION: \(startLocation)")
                print("LAST LOCATION: \(lastLocation)")
                print("FULL DISTANCE: \(traveledDistance)")
                print("STRAIGHT DISTANCE: \(distance)")
                if (distance - fiftyMeterCounter >= 50 || distance - fiftyMeterCounter <= -50){
                    addPinToLocation(location: lastLocation, distanciaRecorrida: distance)
                    fiftyMeterCounter = distance
                }
            }
        }
        lastLocation = locations.last
    }
    
    func addPinToLocation(location: CLLocation, distanciaRecorrida: Double){
        let pin = MKPointAnnotation()
        pin.title = "Latitude: \(location.coordinate.latitude) Longitude: \(location.coordinate.longitude)"
        pin.subtitle = "Distancia recorrida: \(distanciaRecorrida)"
        pin.coordinate = location.coordinate
        mapa.addAnnotation(pin)
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse {
            manejador.startUpdatingLocation()
            mapa.showsUserLocation = true
        }else{
            manejador.stopUpdatingLocation()
            mapa.showsUserLocation = false
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func setStandardView(_ sender: Any) {
        mapa.mapType = MKMapType.standard
    }
    
    @IBAction func setSatelliteView(_ sender: Any) {
        mapa.mapType = MKMapType.satellite
    }
    
    @IBAction func setHybridView(_ sender: Any) {
        mapa.mapType = MKMapType.hybrid
    }
    


}

