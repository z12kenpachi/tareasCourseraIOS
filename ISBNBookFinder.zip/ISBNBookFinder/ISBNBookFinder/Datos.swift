//
//  Datos.swift
//  ISBNBookFinder
//
//  Created by Daniel Rodriguez on 1/29/17.
//  Copyright © 2017 Daniel Rodriguez. All rights reserved.
//

import Foundation

public class Book {

    var title: String = ""
    var authors: String = ""
    var cover: String? = nil
    
    init(titleR: String, authorsR: String, coverR: String?){
        self.title=titleR
        self.authors=authorsR
        self.cover=coverR
    
    }
    
}

class Singleton {
    
    //MARK: Shared Instance
    
    static let sharedInstance : Singleton = {
        let instance = Singleton(array: [])
        return instance
    }()
    
    //MARK: Local Variable
    
    var emptyStringArray : [String]
    
    //MARK: Init
    
    init( array : [String]) {
        emptyStringArray = array
    }
}

class SingletonBook{
    var bookList: [Book] = []
    
    private static var sBook: SingletonBook?
    
    static func currentBook() -> SingletonBook {
        if sBook == nil {
            sBook = SingletonBook()
        }
        return sBook!
    }
}
