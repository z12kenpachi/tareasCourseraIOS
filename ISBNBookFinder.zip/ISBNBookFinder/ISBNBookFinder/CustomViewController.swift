//
//  CustomViewController.swift
//  ISBNBookFinder
//
//  Created by Daniel Rodriguez on 1/29/17.
//  Copyright © 2017 Daniel Rodriguez. All rights reserved.
//

import UIKit

class CustomViewController: UIViewController {

    var txtAreaText = ""
    var imgAreaImage = ""
    @IBOutlet weak var txtResponseArea: UITextView!
    @IBOutlet weak var imgArea: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.txtResponseArea.text = txtAreaText
        if (imgAreaImage == ""){
            self.imgArea.image = UIImage(named: "brokenIcon")
        }else {
            let urlForDownload = imgAreaImage
            let url = NSURL(string: urlForDownload)
            let data = NSData(contentsOf:url! as URL)
            self.imgArea.image = UIImage(data:data! as Data)
        }
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
