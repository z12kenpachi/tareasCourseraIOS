//
//  CustomCell.swift
//  ISBNBookFinder
//
//  Created by Daniel Rodriguez on 1/29/17.
//  Copyright © 2017 Daniel Rodriguez. All rights reserved.
//

import UIKit

class CustomCell: UITableViewCell {
    
    
    @IBOutlet weak var lblISBN: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
