//
//  ViewController.swift
//  ISBNBookFinder
//
//  Created by Daniel Rodriguez on 1/12/17.
//  Copyright © 2017 Daniel Rodriguez. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var txtISBN: UITextField!
    @IBOutlet weak var txtResponseArea: UITextView!
    var ISBNUrl: String = "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.txtISBN.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.txtISBN.resignFirstResponder()
        self.txtResponseArea.text = ""
        let responseText = cargaSincronaDeISBN()
        if (responseText! == "{}"){
            self.txtResponseArea.text = "Error: Código ISBN incorrecto"
        }else{
            self.txtResponseArea.text = responseText
        }
        return true
    }
    
    func cargaSincronaDeISBN() -> String?{
        
        let urls: String = ISBNUrl + self.txtISBN.text!
        let url = NSURL(string: urls)
        let datos: NSData? = NSData(contentsOf: url as! URL)
        if (datos != nil) {
            let texto = NSString(data: datos as! Data, encoding: String.Encoding.utf8.rawValue)
            return (texto as! String)
        }
        let alert = UIAlertController(title: "Sin internet",
                                      message: "No hay conexión a internet",
                                      preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Aceptar", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
        return ("Error: No existe conexión a internet")
    }

}

