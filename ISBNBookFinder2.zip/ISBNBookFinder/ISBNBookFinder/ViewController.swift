//
//  ViewController.swift
//  ISBNBookFinder
//
//  Created by Daniel Rodriguez on 1/12/17.
//  Copyright © 2017 Daniel Rodriguez. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var txtISBN: UITextField!
    @IBOutlet weak var txtResponseArea: UITextView!
    var ISBNUrl: String = "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.txtISBN.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.txtISBN.resignFirstResponder()
        self.txtResponseArea.text = ""
        let responseText = cargaSincronaDeISBN()
        let responseTupla = cargaSincronaDeISBN2()
        if (responseText! == "{}"){
            self.txtResponseArea.text = "Error: Código ISBN incorrecto"
        }else{
            //self.txtResponseArea.text = responseText
            self.txtResponseArea.text = "Título del libro: \(responseTupla.titulo) \n\nAutor(es): \(responseTupla.autores) \n\nPortada: \(responseTupla.portada!)"
        }
        return true
    }
    
    func cargaSincronaDeISBN() -> String?{
        
        let urls: String = ISBNUrl + self.txtISBN.text!
        let url = NSURL(string: urls)
        let datos: NSData? = NSData(contentsOf: url as! URL)
        if (datos != nil) {
            let texto = NSString(data: datos as! Data, encoding: String.Encoding.utf8.rawValue)
            return (texto as! String)
        }
        let alert = UIAlertController(title: "Sin internet",
                                      message: "No hay conexión a internet",
                                      preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Aceptar", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
        return ("Error: No existe conexión a internet")
    }
    
    func cargaSincronaDeISBN2() -> (titulo : String, autores: String, portada: String?){
        
        var authors: String = ""
        var title: String = ""
        var cover: String = ""
        let urls: String = ISBNUrl + self.txtISBN.text!
        let dicoRoot: String = "ISBN:\(self.txtISBN.text!)"
        let url = NSURL(string: urls)
        let datos: NSData? = NSData(contentsOf: url as! URL)
        if (datos != nil) {
            let datosText = NSString(data: datos as! Data, encoding: String.Encoding.utf8.rawValue)
            if (datosText != "{}"){
                do {
                    let json = try JSONSerialization.jsonObject(with: datos! as Data, options: .mutableLeaves)
                    let dico1 = json as! NSDictionary
                    let dico2 = dico1[dicoRoot] as! NSDictionary
                    let dico3 = dico2["authors"] as! NSArray
                    let dico3_1 = dico3[0] as! NSDictionary
                    authors = dico3_1["name"]! as! String
                    let dico4 = dico2["title"] as! String
                    title = dico4
                    if (dico2["cover"] != nil){
                        let dico5 = dico2["cover"] as! NSDictionary
                        if((dico5["large"]) != nil){
                            cover = dico5["large"] as! String
                        }else if((dico5["medium"]) != nil){
                            cover = dico5["medium"] as! String
                        }else if((dico5["small"]) != nil){
                            cover = dico5["small"] as! String
                        }else{
                            cover = "No hay imagen de la portada"
                        }
                    }
                    return (title, authors, cover)
                }
                catch _ {
                    
                }
            
            }else{
                return ("","","")
            }
        }
        let alert = UIAlertController(title: "Sin internet",
                                      message: "No hay conexión a internet",
                                      preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Aceptar", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
        return ("","","")
    }

}

