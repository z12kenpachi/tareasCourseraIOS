//
//  MasaTypeViewController.swift
//  TablePractice
//
//  Created by Daniel Rodriguez on 1/8/17.
//  Copyright © 2017 Daniel Rodriguez. All rights reserved.
//

import UIKit

class MasaTypeViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    
    @IBOutlet weak var pckType: UIPickerView!
    var pickerData: [String] = [String]()
    var selectedRow: String = ""
    var pizzaSize: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Paso 2 de 5"
        pickerData = ["Delgada", "Crujiente", "Gruesa"]
        self.pckType.dataSource = self;
        self.pckType.delegate = self;
        self.selectedRow = pickerData[0]
        print("Tamaño de la pizza: \(pizzaSize)")
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count;
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        if(row == 0)
        {
            print("selected row: \(row)")
            self.selectedRow = pickerData[row]
        }
        else if(row == 1)
        {
            print("selected row: \(row)")
            self.selectedRow = pickerData[row]
        }
        else
        {
            print("selected row: \(row)")
            self.selectedRow = pickerData[row]
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let sigVista = segue.destination as! CheeseTypeViewController
        sigVista.pizzaSize = self.pizzaSize
        sigVista.masaType = selectedRow
    }
    
    
}
