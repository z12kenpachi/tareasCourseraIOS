//
//  IngredientsTableViewController.swift
//  TablePractice
//
//  Created by Daniel Rodriguez on 1/8/17.
//  Copyright © 2017 Daniel Rodriguez. All rights reserved.
//

import UIKit

class IngredientsTableViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
