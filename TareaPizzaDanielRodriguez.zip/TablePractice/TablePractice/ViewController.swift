//
//  ViewController.swift
//  TablePractice
//
//  Created by Daniel Rodriguez on 1/8/17.
//  Copyright © 2017 Daniel Rodriguez. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!
    var ingredients = ["Jamón", "Pepperonni", "Pavo", "Salchicha", "Aceituna", "Cebolla", "Pimiento", "Piña", "Anchoa"]
    var pizzaSize: String = ""
    var masaType: String = ""
    var cheeseType: String = ""
    var tableData: [String] = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.navigationItem.title = "Paso 4 de 5"
        print("Tamaño de la pizza: \(pizzaSize), Tipo de masa: \(masaType), Tipo de queso \(cheeseType)")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ingredients.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CustomCell
        cell.lblIngredients.text = ingredients[indexPath.row]
        return cell
    }
    
    
    @IBAction func countTable(_ sender: Any) {
        
        self.tableData.removeAll()
        for cell in self.tableView.visibleCells{
            let cell2 = cell as! CustomCell
            if(cell2.switchIng.isOn){
                tableData.append(cell2.lblIngredients.text!)
            }
        }
        
        
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if identifier == "ingExtraSegue" {
            if tableData.count > 5 || tableData.count < 1 {
                let alertController2 = UIAlertController(title: "Error", message: "Seleccione entre 1 y 5 Ingredientes", preferredStyle: UIAlertControllerStyle.alert)
                alertController2.addAction(UIAlertAction(title:"OK", style: UIAlertActionStyle.default, handler: nil))
                self.present(alertController2, animated: true, completion: nil)
                return false
            }else{
            return true
            }
        }
        return true
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let sigVista = segue.destination as! ConfirmationViewController
        sigVista.pizzaSize = self.pizzaSize
        sigVista.masaType = self.masaType
        sigVista.cheeseType = self.cheeseType
        sigVista.ingredients = tableData
    }
    
    

}

