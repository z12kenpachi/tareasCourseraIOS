//
//  CustomCell.swift
//  TablePractice
//
//  Created by Daniel Rodriguez on 1/8/17.
//  Copyright © 2017 Daniel Rodriguez. All rights reserved.
//

import UIKit

class CustomCell: UITableViewCell {

    
    @IBOutlet weak var lblIngredients: UILabel!
    @IBOutlet weak var switchIng: UISwitch!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.switchIng.setOn(false, animated: false)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
