//
//  ConfirmationViewController.swift
//  TablePractice
//
//  Created by Daniel Rodriguez on 1/8/17.
//  Copyright © 2017 Daniel Rodriguez. All rights reserved.
//

import UIKit

class ConfirmationViewController: UIViewController {
    
    var pizzaSize: String = ""
    var masaType: String = ""
    var cheeseType: String = ""
    var ingredients: [String] = [String]()
    var ordenCompleta: String = ""
    @IBOutlet weak var txtConfirmacion: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Paso 5 de 5"
        print("Tamaño de la pizza: \(pizzaSize), Tipo de masa: \(masaType), Tipo de queso \(cheeseType) \nIngredientes Extra:")
        ordenCompleta = "Tamaño de la pizza: \(pizzaSize)\n" + "Tipo de masa: \(masaType)\n" + "Tipo de queso \(cheeseType)\n" +
            "Ingredientes Extra:\n"
        var IngExtra: Int = 0
        for ingredient in ingredients {
            IngExtra += 1
            ordenCompleta += "\(IngExtra)- \(ingredient)\n"
            print("\(IngExtra)- \(ingredient)")
        }
        
        self.txtConfirmacion.text = ordenCompleta
        

    }
    
    
    @IBAction func confirmOrder66(_ sender: Any) {
        let alertController = UIAlertController(title: "Pachi's Pizza", message: "Desea confirmar la orden?", preferredStyle: UIAlertControllerStyle.alert)
        alertController.addAction(UIAlertAction(title:"OK", style: UIAlertActionStyle.default, handler: {
            (action: UIAlertAction!) in
            print("Handle OK logic Here")
            let viewControllers: [UIViewController] = self.navigationController!.viewControllers
            for aViewController in viewControllers{
                if(aViewController is FirstViewController){
                    self.navigationController!.popToViewController(aViewController, animated: true)
                    let alertController2 = UIAlertController(title: "Pachi's Pizza", message: "Hemos procesado su orden de manera exitosa", preferredStyle: UIAlertControllerStyle.alert)
                    alertController2.addAction(UIAlertAction(title:"OK", style: UIAlertActionStyle.default, handler: nil))
                    aViewController.present(alertController2, animated: true, completion: nil)
                }
            }
        }))
        alertController.addAction(UIAlertAction(title:"Cancelar", style: UIAlertActionStyle.cancel, handler: {
            (action: UIAlertAction!) in
            print("Handle Cancel logic Here")
        }))
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
